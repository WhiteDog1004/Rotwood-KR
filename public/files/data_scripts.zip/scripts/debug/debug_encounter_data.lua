return {
  acceptable_variance=20.0,
  growth_values={ 2, 2, 1.25,},
  ideal_health_values={ 2000, 3000, 8000,},
}