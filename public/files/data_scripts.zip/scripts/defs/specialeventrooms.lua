local SpecialEventRoom = require("defs.specialeventrooms.specialeventroom")
require("defs.specialeventrooms.minigamespecialeventrooms")
require("defs.specialeventrooms.conversationspecialeventrooms")
return SpecialEventRoom
