local EquipmentGem = require "defs.equipmentgems.equipmentgem"

require("defs.equipmentgems.damagegems")
require("defs.equipmentgems.supportgems")
require("defs.equipmentgems.sustaingems")

return EquipmentGem