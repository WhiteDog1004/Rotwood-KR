Files here correspond to lua files in ../scripts/content/localizations/
